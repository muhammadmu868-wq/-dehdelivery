const state={
  role:null, screen:"login", village:"Деҳaи Нав", cart:[],
  products:[
    {id:1,name:"Нон",price:3,emoji:"🥖"},
    {id:2,name:"Шир (1 л)",price:8,emoji:"🥛"},
    {id:3,name:"Равған",price:18,emoji:"🫙"},
    {id:4,name:"Об (1.5 л)",price:4,emoji:"💧"},
    {id:5,name:"Сабзавот",price:12,emoji:"🥬"},
    {id:6,name:"Орди 1 кг",price:12,emoji:"🌾"}
  ],
  orders: JSON.parse(localStorage.getItem("dd_orders")||"[]"),
  messages: JSON.parse(localStorage.getItem("dd_messages")||"[]")
};

function save(){localStorage.setItem("dd_orders",JSON.stringify(state.orders));localStorage.setItem("dd_messages",JSON.stringify(state.messages))}
function money(n){return n+" сомонӣ"}
function total(){return state.cart.reduce((s,x)=>s+x.price*x.qty,0)}
function app(){document.getElementById("app").innerHTML=render()}
function render(){
  if(state.screen==="login") return login();
  if(state.screen==="village") return village();
  if(state.role==="customer") return customer();
  if(state.role==="courier") return courier();
  if(state.role==="store") return store();
  if(state.role==="admin") return admin();
  return login();
}
function shell(title,body,nav=true){
  return `<div class="wrap"><div class="top"><div class="brand">Deh<span>Delivery</span></div><div class="muted">${state.village}</div></div>${body}${nav?`<div class="nav">
  <button onclick="go('home')" class="${state.screen==='home'?'active':''}">🏠<br>Асосӣ</button>
  <button onclick="go('orders')" class="${state.screen==='orders'?'active':''}">📦<br>Фармоиш</button>
  <button onclick="go('chat')" class="${state.screen==='chat'?'active':''}">💬<br>Чат</button>
  <button onclick="logout()">↩️<br>Баромад</button></div>`:""}</div>`
}
function login(){
 return `<div class="wrap"><div class="screen">
 <div class="logo">🛵</div><h1>DehDelivery</h1><p class="muted">Доставка барои деҳот</p>
 <input id="phone" class="input" placeholder="+992 90 123 45 67" inputmode="tel">
 <button class="btn" onclick="chooseVillage()">Давом додан</button>
 <p class="muted">Барои версияи тестӣ SMS-код талаб намешавад.</p>
 </div></div>`
}
function chooseVillage(){
 state.screen="village";app()
}
function village(){
 return `<div class="wrap"><div class="screen"><h2>📍 Ҷойи худро интихоб кунед</h2>
 <select id="vil" class="select"><option>Деҳaи Нав</option><option>Деҳaи Сомон</option><option>Деҳaи Гулзор</option></select>
 <h3>Кӣ ҳастед?</h3>
 <button class="role" onclick="enter('customer')">👤 <b>Муштарӣ</b><br><span class="muted">Фармоиш додан</span></button>
 <button class="role" onclick="enter('store')">🏪 <b>Мағоза</b><br><span class="muted">Фармоиш қабул кардан</span></button>
 <button class="role" onclick="enter('courier')">🛵 <b>Курьер</b><br><span class="muted">Доставка кардан</span></button>
 <button class="role" onclick="enter('admin')">👨‍💼 <b>Admin</b><br><span class="muted">Идора кардани система</span></button>
 </div></div>`
}
function enter(role){state.village=document.getElementById("vil").value;state.role=role;state.screen="home";app()}
function logout(){state.role=null;state.screen="login";app()}
function go(s){state.screen=s;app()}

function customer(){
 let body="";
 if(state.screen==="home") body=`<div class="screen"><h2>Салом 👋</h2><div class="grid">
 <div class="cat" onclick="go('shop')">🛒<b>Маҳсулот</b></div><div class="cat" onclick="go('shop')">🍔<b>Хӯрок</b></div>
 <div class="cat" onclick="go('shop')">💊<b>Дорухона</b></div><div class="cat" onclick="go('shop')">🥖<b>Нон</b></div>
 </div><button class="btn" onclick="go('shop')">🛍 Харид кардан</button></div>`;
 if(state.screen==="shop") body=shop();
 if(state.screen==="cart") body=cart();
 if(state.screen==="checkout") body=checkout();
 if(state.screen==="orders") body=customerOrders();
 if(state.screen==="chat") body=customerChat();
 return shell("",body);
}
function shop(){
 return `<div class="screen"><div class="row"><button class="back" onclick="go('home')">‹</button><h2>Дӯкони марказӣ</h2><span></span></div>
 ${state.products.map(p=>`<div class="card product"><div><b>${p.emoji} ${p.name}</b><div class="muted">${money(p.price)}</div></div>
 <div class="qty"><button class="small" onclick="add(${p.id},-1)">−</button><b>${(state.cart.find(x=>x.id===p.id)||{qty:0}).qty}</b><button class="small" onclick="add(${p.id},1)">+</button></div></div>`).join("")}
 <button class="btn" onclick="go('cart')">🛒 Ба сабад (${state.cart.reduce((s,x)=>s+x.qty,0)})</button></div>`
}
function add(id,d){
 let p=state.products.find(x=>x.id===id), x=state.cart.find(x=>x.id===id);
 if(!x&&d>0)state.cart.push({...p,qty:1}); else if(x){x.qty+=d;if(x.qty<=0)state.cart=state.cart.filter(y=>y.id!==id)}
 app()
}
function cart(){
 return `<div class="screen"><h2>🛒 Сабади шумо</h2>${state.cart.length?state.cart.map(x=>`<div class="card row"><span>${x.emoji} ${x.name} × ${x.qty}</span><b>${money(x.price*x.qty)}</b></div>`).join(""):`<div class="empty">Сабад холӣ аст</div>`}
 ${state.cart.length?`<div class="row"><span>Маҳсулот</span><b>${money(total())}</b></div><div class="row"><span>Доставка</span><b>5 сомонӣ</b></div><div class="row total"><span>ҲАМАГӢ</span><span>${money(total()+5)}</span></div><button class="btn" onclick="go('checkout')">Фармоиш додан</button>`:""}</div>`
}
function checkout(){
 return `<div class="screen"><h2>📍 Суроғаи доставка</h2><input id="street" class="input" placeholder="Кӯча"><input id="house" class="input" placeholder="Хона"><input id="note" class="input" placeholder="Нишон: наздики мактаб"><input id="phone2" class="input" placeholder="Рақами телефон" inputmode="tel"><div class="card"><b>Пардохт:</b> 💵 Нақдӣ ҳангоми гирифтани фармоиш</div><button class="btn" onclick="placeOrder()">Тасдиқ кардани фармоиш</button></div>`
}
function placeOrder(){
 const o={id:Date.now(),user:"Муштарӣ",village:state.village,street:document.getElementById("street").value||"Марказӣ",house:document.getElementById("house").value||"12",note:document.getElementById("note").value||"",phone:document.getElementById("phone2").value||"",items:state.cart,total:total()+5,status:"Нав",courier:null,created:new Date().toLocaleString("tg-TJ")};
 state.orders.unshift(o);state.cart=[];save();state.screen="orders";app()
}
function customerOrders(){
 return `<div class="screen"><h2>📦 Фармоишҳои ман</h2>${state.orders.length?state.orders.map(o=>`<div class="card"><div class="row"><b>№${String(o.id).slice(-4)}</b><span class="status">${o.status}</span></div><p>${o.items.map(x=>x.name+" × "+x.qty).join(", ")}</p><b>${money(o.total)}</b><p class="muted">📍 ${o.village}, ${o.street}, ${o.house}</p></div>`).join(""):`<div class="empty">Ҳоло фармоиш нест</div>`}</div>`
}
function customerChat(){
 const msgs=state.messages.filter(m=>m.orderId===state.orders[0]?.id);
 return chatUI("Чати фармоиш",msgs,"customer")
}
function chatUI(title,msgs,role){
 return `<div class="screen"><h2>💬 ${title}</h2><div class="chat"><div class="messages">${msgs.map(m=>`<div class="msg ${m.role===role?'me':''}">${m.text}</div>`).join("")||'<div class="empty">Паём нест</div>'}</div><div class="chatbar"><input id="msg" class="input" placeholder="Паём нависед..."><button class="small" onclick="sendMsg('${role}')">➤</button></div></div></div>`
}
function sendMsg(role){
 let order=state.orders[0];if(!order)return;
 let text=document.getElementById("msg").value.trim();if(!text)return;
 state.messages.push({orderId:order.id,role,text,at:Date.now()});save();app()
}

function courier(){
 if(state.screen==="chat"){let o=state.orders[0];return shell("",chatUI("Чат бо мағоза",state.messages.filter(m=>m.orderId===o?.id),"courier"))}
 let available=state.orders.filter(o=>o.status==="Нав"||o.status==="Тайёр шуд");
 let body=`<div class="screen"><h2>🛵 Фармоишҳои нав</h2>${available.length?available.map(o=>`<div class="card"><div class="row"><b>№${String(o.id).slice(-4)}</b><span>${money(o.total)}</span></div><p>📍 ${o.village}, ${o.street}, ${o.house}</p><p>${o.items.map(x=>x.name+" × "+x.qty).join(", ")}</p><button class="btn" onclick="acceptOrder(${o.id})">Қабул кардан</button></div>`).join(""):`<div class="empty">Ҳоло фармоиши нав нест</div>`}</div>`;
 if(state.screen==="orders") body=`<div class="screen"><h2>📦 Фармоишҳои ман</h2>${state.orders.filter(o=>o.courier).map(o=>`<div class="card"><b>№${String(o.id).slice(-4)}</b><p>📍 ${o.village}, ${o.street}, ${o.house}</p><p class="status">${o.status}</p><button class="btn" onclick="updateOrder(${o.id})">Тағйири статус</button><button class="btn secondary" onclick="openChat(${o.id})">💬 Чат бо мағоза</button></div>`).join("")}</div>`;
 return shell("",body)
}
function acceptOrder(id){let o=state.orders.find(x=>x.id===id);o.courier="Курьер";o.status="Қабул шуд";save();state.screen="orders";app()}
function updateOrder(id){let o=state.orders.find(x=>x.id===id);o.status=o.status==="Қабул шуд"?"Дар роҳ":o.status==="Дар роҳ"?"Расонида шуд":"Қабул шуд";save();app()}
function openChat(id){state.orders=state.orders.sort((a,b)=>b.id-a.id);state.screen="chat";app()}

function store(){
 if(state.screen==="chat"){let o=state.orders[0];return shell("",chatUI("Чат бо курьер",state.messages.filter(m=>m.orderId===o?.id),"store"))}
 let body=`<div class="screen"><h2>🏪 Фармоишҳои нав</h2>${state.orders.map(o=>`<div class="card"><div class="row"><b>№${String(o.id).slice(-4)}</b><span class="status">${o.status}</span></div><p>👤 ${o.user}</p><p>${o.items.map(x=>x.name+" × "+x.qty).join(", ")}</p><b>${money(o.total)}</b><button class="btn" onclick="storeReady(${o.id})">${o.status==="Нав"?"Қабул кардан":"Тайёр шуд"}</button><button class="btn secondary" onclick="openChat(${o.id})">💬 Чат бо курьер</button></div>`).join("")||'<div class="empty">Фармоиш нест</div>'}</div>`;
 return shell("",body)
}
function storeReady(id){let o=state.orders.find(x=>x.id===id);o.status=o.status==="Нав"?"Қабул шуд":"Тайёр шуд";save();app()}

function admin(){
 let revenue=state.orders.filter(o=>o.status==="Расонида шуд").reduce((s,o)=>s+o.total,0);
 return shell("",`<div class="screen"><h2>👨‍💼 Admin</h2><div class="grid"><div class="card"><b>Фармоиш</b><h2>${state.orders.length}</h2></div><div class="card"><b>Даромад</b><h2>${money(revenue)}</h2></div></div><div class="card"><b>Охирин фармоишҳо</b>${state.orders.map(o=>`<p>№${String(o.id).slice(-4)} — ${o.status} — ${money(o.total)}</p>`).join("")||"<p>Нест</p>"}</div><button class="btn" onclick="clearDemo()">Тоза кардани маълумоти тестӣ</button></div>`)
}
function clearDemo(){state.orders=[];state.messages=[];save();app()}
app();
